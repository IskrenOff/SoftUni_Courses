﻿namespace BookingApp.Repositories
{
    internal interface IRepository
    {
    }
}