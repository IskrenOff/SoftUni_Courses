﻿namespace Easter.Repositories
{
	public interface IRepository
	{
	}
}