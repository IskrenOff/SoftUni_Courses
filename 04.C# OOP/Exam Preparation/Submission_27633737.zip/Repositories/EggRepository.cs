﻿using Easter.Models.Eggs.Contracts;
using Easter.Repositories.Contracts;
using System.Collections.Generic;
using System.Linq;

namespace Easter.Repositories
{
	public class EggRepository : IRepository<IEgg>
	{
		private List<IEgg> models;

		public IReadOnlyCollection<IEgg> Models => this.models;

		public EggRepository()
		{
			this.models = new List<IEgg>();
		}

		public void Add(IEgg model) => this.models.Add(model);

		public IEgg FindByName(string name) => this.Models.FirstOrDefault(n => n.Name == name);

		public bool Remove(IEgg model) => this.models.Remove(model);
	}
}
