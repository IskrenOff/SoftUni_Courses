﻿using Easter.Models.Bunnies;
using Easter.Models.Bunnies.Contracts;
using Easter.Models.Dyes;
using Easter.Models.Eggs;
using Easter.Models.Eggs.Contracts;
using Easter.Models.Workshops;
using Easter.Models.Workshops.Contracts;
using Easter.Repositories;
using Easter.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Easter.Core.Contracts
{
	public class Controller : IController
	{
		private BunnyRepository bunnies;
		private EggRepository eggs;
		private IWorkshop workshop;

		public Controller()
		{
			this.bunnies = new BunnyRepository();
			this.eggs = new EggRepository();
			this.workshop = new Workshop();
		}

		public string AddBunny(string bunnyType, string bunnyName)
		{
			if (bunnyType == typeof(HappyBunny).Name)
			{
				this.bunnies.Add(new HappyBunny(bunnyName));				
			}
			else if (bunnyType == typeof(SleepyBunny).Name)
			{
				this.bunnies.Add(new SleepyBunny(bunnyName));
			}
			else
			{
				throw new InvalidOperationException(ExceptionMessages.InvalidBunnyType);
			}

			return string.Format(OutputMessages.BunnyAdded, bunnyType, bunnyName);
		}

		public string AddDyeToBunny(string bunnyName, int power)
		{
			IBunny bunny = this.bunnies.FindByName(bunnyName);

			if (bunny == null)
			{
				throw new InvalidOperationException(ExceptionMessages.InexistentBunny);
			}

			bunny.AddDye(new Dye(power));

			return string.Format(OutputMessages.DyeAdded, power, bunnyName);
		}

		public string AddEgg(string eggName, int energyRequired)
		{
			this.eggs.Add(new Egg(eggName, energyRequired));

			return string.Format(OutputMessages.EggAdded, eggName);
		}

		public string ColorEgg(string eggName)
		{
			IEgg egg = this.eggs.FindByName(eggName);
			IBunny bunny = null;

			List<IBunny> bestBunnies = this.bunnies.Models.Where(x => x.Energy >= 50 && x.Dyes.Count > 0).OrderByDescending(x => x.Energy).ToList();

			if (bestBunnies.Count == 0)
			{
				throw new InvalidOperationException(ExceptionMessages.BunniesNotReady);
			}

			bool isExitLoop = false;
			while (bestBunnies.Count > 0 && !egg.IsDone())
			{
				bunny = bestBunnies.First();
				this.workshop.Color(egg, bunny);

				if (bunny.Energy == 0)
				{
					//bestBunnies.Remove(bunny);
					this.bunnies.Remove(bunny);
					bestBunnies = this.bunnies.Models.Where(x => x.Energy >= 50 && x.Dyes.Count > 0).OrderByDescending(x => x.Energy).ToList();
				}
				else if (bunny.Dyes.Count == 0)
				{
					bestBunnies = this.bunnies.Models.Where(x => x.Energy >= 50 && x.Dyes.Count > 0).OrderByDescending(x => x.Energy).ToList();
				}				
			}

			if (egg.IsDone())
			{
				return string.Format(OutputMessages.EggIsDone, eggName);
			}
			else
			{
				return string.Format(OutputMessages.EggIsNotDone, eggName);
			}
		}

		public string Report()
		{
			StringBuilder sb = new StringBuilder();

			List<IEgg> eggsready = this.eggs.Models.Where(x => x.IsDone() == true).ToList();

			sb.AppendLine($"{eggsready.Count} eggs are done!");
			sb.AppendLine("Bunnies info:");

			foreach (IBunny bunny in this.bunnies.Models)
			{
				sb.AppendLine($"Name: {bunny.Name}");
				sb.AppendLine($"Energy: {bunny.Energy}");
				sb.AppendLine($"Dyes: {bunny.Dyes.Count} not finished");
			}

			return sb.ToString().TrimEnd();
		}
	}
}
