﻿using PlanetWars.Models.MilitaryUnits.Contracts;
using PlanetWars.Models.Planets.Contracts;
using PlanetWars.Models.Weapons.Contracts;
using PlanetWars.Repositories;
using PlanetWars.Repositories.Contracts;
using PlanetWars.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using PlanetWars.Models.MilitaryUnits;

namespace PlanetWars.Models.Planets
{
    public class Planet : IPlanet
    {
        private  readonly UnitRepository units;
        private  readonly WeaponRepository weapons;
        private string name;
        private double budget;
        private double militaryPower;

        public Planet(string name, double budget)
        {
            Name = name;
            Budget = budget;
            units = new UnitRepository();
            weapons = new WeaponRepository();
        }

        public string Name
        {
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(ExceptionMessages.InvalidPlanetName);
                }
                name = value;
            }
        }

        public double Budget
        {
            get => budget;
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidBudgetAmount);
                }
                budget = value;
            }
        }

        public double MilitaryPower
        {
            get => Math.Round(militaryPower,3);
            private set
            {
                militaryPower = Army.Sum(x => x.EnduranceLevel) + Weapons.Sum(x => x.DestructionLevel);

                if (units.FindByName("AnonymousImpactUnit") != null)
                {
                    militaryPower *= 1.3;
                }
                if (weapons.FindByName("NuclearWeapon") != null)
                {
                    militaryPower *= 1.45;
                }
            }
        }

        public IReadOnlyCollection<IMilitaryUnit> Army => units.Models;
        public IReadOnlyCollection<IWeapon> Weapons => weapons.Models;

        public void AddUnit(IMilitaryUnit unit)
        {
            units.AddItem(unit);
        }

        public void AddWeapon(IWeapon weapon)
        {
            weapons.AddItem(weapon);
        }

        public string PlanetInfo()
        {
            StringBuilder sb = new StringBuilder();
            List<string> unitNames = new List<string>();
            List<string> weaponNames = new List<string>();
            foreach (var unit in Army)
            {
                unitNames.Add(unit.GetType().Name);
            }

            foreach (var unit in Weapons)
            {
                weaponNames.Add(unit.GetType().Name);
            }

            sb.AppendLine($"Planet: {name}");
            sb.AppendLine($"--Budget: {budget} billion QUID");
            if (unitNames.Count != 0)
            {
                sb.AppendLine($"--Forces: {string.Join(", ",unitNames)}");
            }
            else
            {
                sb.AppendLine($"--Forces: No units");
            }
            if (weaponNames.Count != 0)
            {
                sb.AppendLine($"--Combat equipment: {string.Join(", ", weaponNames)}");
            }
            else
            {
                sb.AppendLine($"--Combat equipment: No weapons");
            }
            sb.AppendLine($"--Military Power: {militaryPower}");

            return sb.ToString().TrimEnd();

        }

        public void Profit(double amount)
        {
            budget += amount;
        }

        public void Spend(double amount)
        {
            if (budget < amount)
            {
                throw new InvalidOperationException(ExceptionMessages.UnsufficientBudget);
            }
            budget -= amount;
        }

        public void TrainArmy()
        {
            foreach (var item in Army)
            {
                item.IncreaseEndurance();
            }
        }
    }
}
