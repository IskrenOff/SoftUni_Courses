﻿using PlanetWars.Core.Contracts;
using PlanetWars.Models.Planets;
using PlanetWars.Models.Planets.Contracts;
using PlanetWars.Models.Weapons;
using PlanetWars.Repositories;
using PlanetWars.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace PlanetWars.Core
{
    public class Controller : IController
    {
        private readonly PlanetRepository planets;


        public string AddUnit(string unitTypeName, string planetName)
        {
            throw new NotImplementedException();
        }

        public string AddWeapon(string planetName, string weaponTypeName, int destructionLevel)
        {
            Weapon weapon = null;
            IPlanet planet = planets.FindByName(planetName);

            switch (weaponTypeName)
            {
                case "BioChemicalWeapon":
                    weapon = new BioChemicalWeapon(destructionLevel);  
                    break;
                case "NuclearWeapon":
                    weapon = new NuclearWeapon(destructionLevel);
                    break;
                case "SpaceMissiles":
                    weapon = new SpaceMissiles(destructionLevel);
                    break;
                default: string.Format(ExceptionMessages.ItemNotAvailable, weaponTypeName);
                    break;
            }

            if (planets.FindByName(planetName) == null)
            {
                return string.Format(ExceptionMessages.UnexistingPlanet,planetName);
            }
            if (planet.Weapons.FirstOrDefault(x => x.GetType().Name == weaponTypeName) != null)
            {
                return string.Format(ExceptionMessages.WeaponAlreadyAdded,weaponTypeName,planetName);
            }

            return string.Format(OutputMessages.WeaponAdded,planetName,weaponTypeName);
        }

        public string CreatePlanet(string name, double budget)
        {
            IPlanet planet = new Planet(name,budget);

            if (planets.FindByName(name) != null)
            {
                return String.Format(OutputMessages.ExistingPlanet, name);
            }

            planets.AddItem(planet);

            return String.Format(OutputMessages.NewPlanet, name);
        }

        public string ForcesReport()
        {
            throw new NotImplementedException();
        }

        public string SpaceCombat(string planetOne, string planetTwo)
        {
            IPlanet planet1 = planets.FindByName(planetOne);
            IPlanet planet2 = planets.FindByName(planetTwo);

            bool nuclearWeaponPlanet1 = false;
            bool nuclearWeaponPlanet2 = false;

            foreach (var weapon in planet1.Weapons)
            {
                if (weapon.GetType().Name == "NuclearWeapon")
                {
                    nuclearWeaponPlanet1 = true;
                }
            }

            foreach (var weapon in planet2.Weapons)
            {
                if (weapon.GetType().Name == "NuclearWeapon")
                {
                    nuclearWeaponPlanet2 = true;
                }
            }

            if (planet1.MilitaryPower == planet2.MilitaryPower)
            {
                if (nuclearWeaponPlanet1 == nuclearWeaponPlanet2)
                {
                    planet1.Spend(planet1.Budget / 2);
                    planet2.Spend(planet2.Budget / 2);

                    return string.Format(OutputMessages.NoWinner);
                }
                else if (nuclearWeaponPlanet1)
                {
                    planet1.Spend(planet1.Budget / 2);
                    planet1.Profit(planet2.Budget / 2);
                    planets.RemoveItem(planet2.Name);

                    return string.Format(OutputMessages.WinnigTheWar , planet1.Name,planet2.Name);
                }
                else if (nuclearWeaponPlanet2)
                {
                    planet2.Spend(planet2.Budget / 2);
                    planet2.Profit(planet1.Budget / 2);
                    planets.RemoveItem(planet1.Name);

                    return string.Format(OutputMessages.WinnigTheWar, planet2.Name, planet1.Name);
                }
            }

            if (planet1.MilitaryPower > planet2.MilitaryPower)
            {
                planet1.Spend(planet1.Budget / 2);
                planet1.Profit(planet2.Budget / 2);
                planets.RemoveItem(planet2.Name);

                return string.Format(OutputMessages.WinnigTheWar, planet1.Name, planet2.Name);
            }
            else
            {
                planet2.Spend(planet2.Budget / 2);
                planet2.Profit(planet1.Budget / 2);
                planets.RemoveItem(planet1.Name);

                return string.Format(OutputMessages.WinnigTheWar, planet2.Name, planet1.Name);
            }
        }

        public string SpecializeForces(string planetName)
        {
            throw new NotImplementedException();
        }
    }
}
