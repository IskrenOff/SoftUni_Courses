﻿using RobotService.Models.Contracts;
using RobotService.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Repositories
{
    public class SupplementRepository : IRepository<ISupplement>
    {
        private List<ISupplement> supplements;

        public void AddNew(ISupplement model)
        {
            throw new NotImplementedException();
        }

        public ISupplement FindByStandard(int interfaceStandard)
        {
            throw new NotImplementedException();
        }

        public IReadOnlyCollection<ISupplement> Models()
        {
            throw new NotImplementedException();
        }

        public bool RemoveByName(string typeName)
        {
            throw new NotImplementedException();
        }
    }
}
