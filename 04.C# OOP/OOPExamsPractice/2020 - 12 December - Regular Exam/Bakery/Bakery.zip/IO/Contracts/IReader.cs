﻿namespace Bakery.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
