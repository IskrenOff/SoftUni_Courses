﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Basketball
{
    public class Team
    {
        public List<Player> Players;
        public string Name { get; set; }
        public int OpenPositions { get; set; }
        public char Group { get; set; }

        public Team(string name, int openPositions, char group)
        {
            this.Name = name;
            this.OpenPositions = openPositions;
            this.Group = group;
            this.Players = new List<Player>();
        }

        public int Count => this.Players.Count;

        public string AddPlayer(Player player)
        {
            this.OpenPositions--;
            if (this.OpenPositions < 0)
            {
                OpenPositions++;
                return "There are no more open positions.";
            }

            if (string.IsNullOrEmpty(player.Name) || string.IsNullOrEmpty(player.Position))
            {
                this.OpenPositions++;
                return "Invalid player's information.";
            }

            if (player.Rating < 80)
            {
                this.OpenPositions++;
                return "Invalid player's rating.";
            }
            this.Players.Add(player);

            return $"Successfully added {player.Name} to the team." +
                $" Remaining open positions: {this.OpenPositions}.";
        }

        public bool RemovePlayer(string name)
        {
            foreach (Player player in Players)
            {
                if (player.Name == name)
                {
                    this.Players.Remove(player);
                    this.OpenPositions++;
                    return true;
                }
            }
            return false;
        }
        public Player RetirePlayer(string name)
        {
            Player player = this.Players.FirstOrDefault(d => d.Name == name);
            if (player == null)
            {
                return null;
            }
            player.Retired = true;
            return player;
        }
        public int RemovePlayerByPosition(string position)
        {
            //int count = 
            if (this.Players.Any((p => p.Position == position)))
            {
                int count = this.Players.RemoveAll(p => p.Position == position);
                return count;
            }
            return 0;
        }
        public List<Player> AwardPlayers(int games)
        {
            List<Player> players = this.Players.Where(d => d.Games >= games).ToList();
            //foreach (Player player in players)
            //{
            //    Console.WriteLine(player.ToString());
            //}
            return players;
        }

        public string Report()
        {
            var notRetiredPlayers = this.Players.Where(d => d.Retired == false).ToList();
            return $"Active players competing for Team {this.Name} from Group {this.Group}:"
                + Environment.NewLine +
                string.Join(Environment.NewLine, notRetiredPlayers);
        }
    }
}
